export const metadata = { title: "Privacy" }
export default function Privacy() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-16 prose prose-invert">
      <h1>Privacy Policy</h1>
      <p>This demo does not collect personal data. Replace with your policy.</p>
    </div>
  )
}
